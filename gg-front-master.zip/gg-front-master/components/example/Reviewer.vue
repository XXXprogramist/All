<template>
  <v-card flat>
    <v-card-title></v-card-title>
    <v-card-text></v-card-text>
  </v-card>
</template>

<script>
export default {
  props: {
    settings: Object,
    examinee: Object,
    answer: Object
  }
};
</script>

<style>
</style>