export default {
  backEndpoint: process.env.VUE_APP_BACK_ENDPOINT,
  apiEndpoint: process.env.VUE_APP_API_ENDPOINT
};
