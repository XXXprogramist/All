<template>
  <v-layout wrap align-start justify-center style="margin: auto 50px">
    <router-view />
  </v-layout>
</template>

<script>
export default {};
</script>

<style>
.sticky {
  position: sticky;
  top: 0;
  z-index: 1;
}
</style>
